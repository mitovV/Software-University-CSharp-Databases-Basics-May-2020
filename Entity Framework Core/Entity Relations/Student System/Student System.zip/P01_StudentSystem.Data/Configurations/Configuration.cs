﻿namespace P01_StudentSystem.Data.Configurations
{
    internal static class Configuration
    {
        internal static string ConnectionString = @"Server=.\SQLEXPRESS;Database=StudentSystemDB;Integrated Security=true;";
    }
}
