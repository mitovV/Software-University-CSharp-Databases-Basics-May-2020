﻿namespace P03_FootballBetting.Data.Models.Enums
{
    public enum Prediction
    {
        Win = 1,
        Draw = 0,
        Lost = -1
    }
}
