﻿namespace P03_FootballBetting
{
    public class Startup
    {
        public static void Main()
        {
        }
    }
}
