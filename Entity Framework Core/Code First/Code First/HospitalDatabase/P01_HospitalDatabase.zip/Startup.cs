﻿namespace P01_HospitalDatabase
{
    public class Startup
    {
        public static void Main()
        {
        }
    }
}
